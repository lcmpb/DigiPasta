class CreatePessoas < ActiveRecord::Migration
  def change
    create_table :pessoas do |t|
      t.string :name
      t.string :idade
      t.string :email

      t.timestamps null: false
    end
  end
end
