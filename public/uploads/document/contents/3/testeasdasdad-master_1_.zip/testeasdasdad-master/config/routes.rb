Rails.application.routes.draw do
  resources :pessoas
  resources :pessoas
  root 'application#home'
end
