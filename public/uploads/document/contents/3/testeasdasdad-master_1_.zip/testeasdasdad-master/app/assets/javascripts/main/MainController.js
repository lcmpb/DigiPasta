angular.module('app').controller('MainController', function($scope, $http){
  $scope.user = {} 
  $scope.pessoas = []
  $scope.update = function(user) {
    $http.post('http://localhost:3000/pessoas',user)
      .then(function(resp){
        $scope.get()
        $scope.user = {} 
      })
  }

  $scope.get = function() {
    $http.get('http://localhost:3000/pessoas')
    .then(function(pessoas){
      console.log(pessoas)
      $scope.pessoas = pessoas.data
    })
  }

  $scope.get()
});