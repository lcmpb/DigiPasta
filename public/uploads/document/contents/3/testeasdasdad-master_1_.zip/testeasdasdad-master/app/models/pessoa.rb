class Pessoa < ActiveRecord::Base
end
